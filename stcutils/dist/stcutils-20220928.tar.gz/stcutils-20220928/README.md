# STC Tester

This module has been written for use within Sha Tin College Computer Science lessons. It is intended to provide sample inputs for various introductory problems that our students are tasked to complete.

## Install

```
pip3 install stc_tester
```

## Author

* [Paul Baumgarten](https://pbaumgarten.com/)

## License

MIT License (C) 2022 Paul Baumgarten

